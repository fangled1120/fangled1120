// 導覽列在捲動時加入細緻陰影
document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.querySelector(".navbar");
    if (!navbar) return;

    const updateNavbar = () => {
        navbar.style.boxShadow = window.scrollY > 24
            ? "0 4px 20px rgba(36, 36, 36, 0.04)"
            : "none";
    };

    updateNavbar();
    window.addEventListener("scroll", updateNavbar, { passive: true });
});
